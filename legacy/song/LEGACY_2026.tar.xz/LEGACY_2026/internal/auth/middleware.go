package auth

import (
	"context"
	"net/http"
	"strings"

	"github.com/azzurrotech/song/internal/config"
	"github.com/azzurrotech/song/internal/core"
)

// Service wraps auth functionality for middleware use
type Service struct {
	localSvc   *LocalAuthService
	oidcSvc    *OIDCProvider
	sessionMgr *core.SessionManager
}

// NewService creates a unified auth service
func NewService(cfg *config.Config, store *core.Store) (*Service, error) {
	localSvc, err := NewLocalAuthService(cfg, store)
	if err != nil {
		return nil, err
	}

	var oidcSvc *OIDCProvider
	if cfg.OIDCEnabled {
		oidcSvc, err = NewOIDCProvider(cfg)
		if err != nil {
			return nil, err
		}
	}

	return &Service{
		localSvc:   localSvc,
		oidcSvc:    oidcSvc,
		sessionMgr: core.NewSessionManager(store),
	}, nil
}

// RequireAuth is a middleware that requires a valid authentication token
func (s *Service) RequireAuth() mux.MiddlewareFunc {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
			token := ExtractToken(req.Header.Get("Authorization"))
			if token == "" {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}

			user, err := s.localSvc.ValidateToken(token)
			if err != nil {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}

			// Attach user to context
			ctx := context.WithValue(req.Context(), "user", user)
			next.ServeHTTP(w, req.WithContext(ctx))
		})
	}
}

// RequireRole is a middleware that requires the user to have one of the specified roles
func (s *Service) RequireRole(roles ...string) mux.MiddlewareFunc {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
			user, ok := req.Context().Value("user").(*User)
			if !ok {
				http.Error(w, "Forbidden", http.StatusForbidden)
				return
			}

			hasRole := false
			for _, role := range roles {
				if user.Role == role {
					hasRole = true
					break
				}
			}

			if !hasRole {
				http.Error(w, "Forbidden", http.StatusForbidden)
				return
			}

			next.ServeHTTP(w, req)
		})
	}
}

// GetCurrentUser extracts the user from the context
func (s *Service) GetCurrentUser(req *http.Request) (*User, bool) {
	user, ok := req.Context().Value("user").(*User)
	return user, ok
}

// ExtractToken extracts the token from the Authorization header
func ExtractToken(authHeader string) string {
	if authHeader == "" {
		return ""
	}
	parts := strings.SplitN(authHeader, " ", 2)
	if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
		return ""
	}
	return parts[1]
}
