package auth

import (
	"context"
	"fmt"

	"github.com/azzurrotech/song/internal/config"
	"golang.org/x/oauth2"
)

// OIDCConfig holds OIDC provider settings
type OIDCConfig struct {
	Issuer       string
	ClientID     string
	ClientSecret string
	RedirectURL  string
	Scopes       []string
}

// OIDCProvider manages OIDC authentication
type OIDCProvider struct {
	config      *OIDCConfig
	oauthConfig *oauth2.Config
}

// NewOIDCProvider creates a new OIDC provider
func NewOIDCProvider(cfg *config.Config) (*OIDCProvider, error) {
	if !cfg.OIDCEnabled {
		return nil, nil
	}

	// Discover OIDC endpoints (simplified - in production use oidc.Discover)
	// For now, we assume standard endpoints or use the issuer to derive them
	// This is a placeholder for a real OIDC discovery implementation

	oauthConfig := &oauth2.Config{
		ClientID:     cfg.OIDCClientID,
		ClientSecret: cfg.OIDCClientSecret,
		Endpoint: oauth2.Endpoint{
			AuthURL:  fmt.Sprintf("%s/authorize", cfg.OIDCIssuer),
			TokenURL: fmt.Sprintf("%s/token", cfg.OIDCIssuer),
		},
		RedirectURL: cfg.OIDCRedirectURL, // Should be set in config
		Scopes:      []string{"openid", "profile", "email"},
	}

	return &OIDCProvider{
		config: &OIDCConfig{
			Issuer:       cfg.OIDCIssuer,
			ClientID:     cfg.OIDCClientID,
			ClientSecret: cfg.OIDCClientSecret,
			RedirectURL:  cfg.OIDCRedirectURL,
			Scopes:       oauthConfig.Scopes,
		},
		oauthConfig: oauthConfig,
	}, nil
}

// GetAuthURL returns the URL to redirect users to for login
func (p *OIDCProvider) GetAuthURL(state string) string {
	return p.oauthConfig.AuthCodeURL(state, oauth2.AccessTypeOffline)
}

// ExchangeToken exchanges an authorization code for an access token
func (p *OIDCProvider) ExchangeToken(ctx context.Context, code string) (*oauth2.Token, error) {
	return p.oauthConfig.Exchange(ctx, code)
}

// UserInfo fetches user information from the OIDC provider
func (p *OIDCProvider) UserInfo(ctx context.Context, token *oauth2.Token) (map[string]interface{}, error) {
	// In production, use the OIDC userinfo endpoint
	// This is a simplified placeholder
	client := p.oauthConfig.Client(ctx, token)
	// Make request to userinfo endpoint
	// Parse response
	return map[string]interface{}{
		"sub":   "user_id_from_provider",
		"name":  "John Doe",
		"email": "john@example.com",
	}, nil
}
