package auth

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"time"

	"github.com/azzurrotech/song/internal/config"
	"github.com/azzurrotech/song/internal/core"
)

// LocalAuthService handles local username/password authentication
type LocalAuthService struct {
	config     *config.Config
	userMgr    *core.UserManager
	sessionMgr *core.SessionManager
	jwtSecret  string
}

// NewLocalAuthService creates a new local auth service
func NewLocalAuthService(cfg *config.Config, store *core.Store) (*LocalAuthService, error) {
	return &LocalAuthService{
		config:     cfg,
		userMgr:    core.NewUserManager(store),
		sessionMgr: core.NewSessionManager(store),
		jwtSecret:  cfg.JWTSecret,
	}, nil
}

// ErrInvalidCredentials is returned when login fails
var ErrInvalidCredentials = errors.New("invalid username or password")
var ErrUserExists = errors.New("user already exists")
var ErrUserNotFound = errors.New("user not found")

// Register creates a new user
func (s *LocalAuthService) Register(username, email, password, role string) (*core.User, error) {
	// Check if user exists
	_, err := s.userMgr.GetByUsername(username)
	if err == nil {
		return nil, ErrUserExists
	}

	_, err = s.userMgr.GetByEmail(email)
	if err == nil {
		return nil, errors.New("email already in use")
	}

	// Generate ID
	id := generateID()

	// Create user
	user, err := s.userMgr.Create(id, username, email, password, role)
	if err != nil {
		return nil, err
	}

	return user, nil
}

// Login authenticates a user and creates a session
func (s *LocalAuthService) Login(username, password string, ip, userAgent string) (*Session, error) {
	// Get user
	user, err := s.userMgr.GetByUsername(username)
	if err != nil {
		return nil, ErrInvalidCredentials
	}

	// Verify password
	if !s.userMgr.ValidatePassword(user, password) {
		return nil, ErrInvalidCredentials
	}

	// Generate JWT token
	token, err := s.generateJWT(user)
	if err != nil {
		return nil, fmt.Errorf("failed to generate token: %w", err)
	}

	// Create session
	session, err := s.sessionMgr.Create(
		generateID(),
		user.ID,
		token,
		ip,
		userAgent,
		24*time.Hour, // Session duration
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create session: %w", err)
	}

	return &Session{
		ID:        session.ID,
		UserID:    session.UserID,
		Token:     session.Token,
		ExpiresAt: session.ExpiresAt,
		User:      user,
	}, nil
}

// Logout revokes a session
func (s *LocalAuthService) Logout(token string) error {
	return s.sessionMgr.Revoke(token)
}

// ValidateToken checks if a token is valid and returns the associated user
func (s *LocalAuthService) ValidateToken(token string) (*User, error) {
	// Get session
	session, err := s.sessionMgr.GetByToken(token)
	if err != nil {
		return nil, err
	}

	// Get user
	user, err := s.userMgr.GetByID(session.UserID)
	if err != nil {
		return nil, err
	}

	if !user.Active {
		return nil, errors.New("user account is inactive")
	}

	return &User{
		ID:       user.ID,
		Username: user.Username,
		Email:    user.Email,
		Role:     user.Role,
	}, nil
}

// ChangePassword changes a user's password
func (s *LocalAuthService) ChangePassword(userID, oldPassword, newPassword string) error {
	// Get user
	user, err := s.userMgr.GetByID(userID)
	if err != nil {
		return ErrUserNotFound
	}

	// Verify old password
	if !s.userMgr.ValidatePassword(user, oldPassword) {
		return ErrInvalidCredentials
	}

	// Update password
	_, err = s.userMgr.Update(userID, map[string]interface{}{
		"password": newPassword,
	})
	return err
}

// generateJWT creates a simple JWT-like token (simplified for this example)
// In production, use a proper JWT library like github.com/golang-jwt/jwt/v5
func (s *LocalAuthService) generateJWT(user *core.User) (string, error) {
	// This is a simplified token generation.
	// A real implementation would sign a JWT with the secret.
	// For now, we'll just create a random token and store it in the session.
	// The session validation handles the rest.

	// Generate random bytes
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}

	return hex.EncodeToString(b), nil
}

// generateID creates a unique ID
func generateID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}
