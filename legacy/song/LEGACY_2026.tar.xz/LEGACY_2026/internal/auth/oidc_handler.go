package auth

import (
	"crypto/rand"
	"encoding/hex"
	"net/http"
	"time"

	"github.com/azzurrotech/song/internal/core"
)

// OIDCHandler handles OIDC callbacks
type OIDCHandler struct {
	provider   *OIDCProvider
	sessionMgr *core.SessionManager
	userMgr    *core.UserManager
}

// NewOIDCHandler creates a new OIDC handler
func NewOIDCHandler(provider *OIDCProvider, store *core.Store) *OIDCHandler {
	return &OIDCHandler{
		provider:   provider,
		sessionMgr: core.NewSessionManager(store),
		userMgr:    core.NewUserManager(store),
	}
}

// LoginHandler initiates the OIDC login flow
func (h *OIDCHandler) LoginHandler(w http.ResponseWriter, req *http.Request) {
	state := generateRandomState()
	http.SetCookie(w, &http.Cookie{
		Name:     "oidc_state",
		Value:    state,
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		MaxAge:   300, // 5 minutes
	})

	loginURL := h.provider.GetAuthURL(state)
	http.Redirect(w, req, loginURL, http.StatusTemporaryRedirect)
}

// CallbackHandler handles the OIDC callback
func (h *OIDCHandler) CallbackHandler(w http.ResponseWriter, req *http.Request) {
	code := req.URL.Query().Get("code")
	state := req.URL.Query().Get("state")

	// Verify state
	cookie, err := req.Cookie("oidc_state")
	if err != nil || cookie.Value != state {
		http.Error(w, "Invalid state", http.StatusBadRequest)
		return
	}

	// Exchange code for token
	token, err := h.provider.ExchangeToken(req.Context(), code)
	if err != nil {
		http.Error(w, "Token exchange failed", http.StatusInternalServerError)
		return
	}

	// Get user info
	userInfo, err := h.provider.UserInfo(req.Context(), token)
	if err != nil {
		http.Error(w, "Failed to get user info", http.StatusInternalServerError)
		return
	}

	// Create or update user in local store
	email, _ := userInfo["email"].(string)
	name, _ := userInfo["name"].(string)
	sub, _ := userInfo["sub"].(string)

	// Check if user exists
	user, err := h.userMgr.GetByEmail(email)
	if err != nil {
		// Create new user
		id := generateID()
		user, err = h.userMgr.Create(id, name, email, "", "developer") // No password for OIDC users
		if err != nil {
			http.Error(w, "Failed to create user", http.StatusInternalServerError)
			return
		}
	}

	// Create session
	session, err := h.sessionMgr.Create(
		generateID(),
		user.ID,
		sub, // Use sub as token for simplicity
		req.RemoteAddr,
		req.UserAgent(),
		24*7*time.Hour, // 1 week session
	)
	if err != nil {
		http.Error(w, "Failed to create session", http.StatusInternalServerError)
		return
	}

	// Redirect to dashboard
	http.Redirect(w, req, "/admin/dashboard", http.StatusFound)
}

func generateRandomState() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}
